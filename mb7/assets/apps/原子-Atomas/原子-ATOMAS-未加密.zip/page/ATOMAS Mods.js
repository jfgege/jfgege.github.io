try {
  (function () {
    var f = __$$hmAppManager$$__.currentApp,
      F = f.current;
    new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(f, F),
      "drink",
    );
    DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
    F.module = DeviceRuntimeCore.Page({
      init_view() {
    hmUI.setLayerScrolling(false);
    hmUI.createWidget(hmUI.widget.FILL_RECT, {
      x: 0,
      y: 0,
      w: 194,
      h: 492,
      color: 0x682830
    })
    const nickName = hmSetting.getUserData().nickName
    var mod = hmFS.SysProGetInt('element_mod')
    const max = hmFS.SysProGetInt('element_max') + 1
    const elements = ["H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K",
      "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr",
      "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd", "Pm",
      "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl", "Pb",
      "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr",
      "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds", "Rg", "Cn", "Uut", "Fi", "Uup", "Lv", "Uus", "Uuo"]
    const elements_Select = ["O", "Si", "K", "Ti", "Co", "Ge", "Br", "Kr", "Rb", "Ag", "Er", "Rn"]
    const num_arr = []
    var bts = []
    for (let i = 0; i < elements_Select.length; i++) {
      num_arr.push(elements_Select.indexOf(elements_Select[i]))
    }
    var to_select
    const abilities = ["正原子多10%", "负原子多10%", "正原子多20%/负原子少 10%",
      "有33%的机会产生更高的原子", "20%的链式反应点", "有35%的机会产生更高的聚变结果", "从Mg (12)开始游戏",
      "如果有18个原子，则有33%的机会出现正号", "如果有18个原子，则有33%的机会出现负号","每50轮一个随机原子被摧毁",
      "如果场上有0个原子，积分翻倍", "如果有18个以上原子，有33%的几率得到更多积分"]
    hmUI.createWidget(hmUI.widget.IMG, {
      x: 48,
      y: 10,
      w: 100,
      h: 100,
      src: "atomas.png",
    })
    hmUI.createWidget(hmUI.widget.FILL_RECT, {
      x: 5,
      y: 285,
      w: 184,
      h: 75,
      radius: 11,
      color: 0x561a21
    })
    const text_mod = hmUI.createWidget(hmUI.widget.TEXT, {
      x: 10,
      y: 290,
      w: 174,
      h: 70,
      text_size: 13,
      text_style: hmUI.text_style.WRAP,
      color: 0xffffff,
      text: mod == undefined ? "到达O获得第一次升级" : abilities[mod - 1]
    })
    console.log("user:" + nickName)
    let x = 1
    let y = 75
    var x_arr = []
    var y_arr = []
    for (let i = 0; i < 12; i++) {
      x += 45
      if (i % 4 == 0) {
        x = 12
      }
      if (i % 4 == 0) {
        y += 51
      }
      x_arr.push(x)
      y_arr.push(y)
      let bt = hmUI.createWidget(hmUI.widget.BUTTON, {
        x: x,
        y: y,
        w: 35,
        h: 35,
        radius: 5,
        text: elements_Select[i],
        text_size: 25,
        color: 0x050800,
        press_color: 0xdd4d5,
        normal_color: i == mod - 1 ? 0x0000ff : num_arr[i] < max && max > elements.indexOf(elements_Select[i]) || nickName == "flvluju"  ? 0x00ff00 : 0xff0000,
        click_func: function () {
          to_select = i
          if (num_arr[i] < max && max > elements.indexOf(elements_Select[i]) || nickName == "flvluju") {
            hmUI.showToast({
              text: `已选择 ${elements_Select[i]} 技能`
            })
            text_mod.setProperty(hmUI.prop.MORE,{
              text: abilities[i]
            })
             hmFS.SysProSetInt('element_mod', i + 1)
             mod = hmFS.SysProGetInt('element_mod')
             for (let i = 0; i < 12; i++) {
              bts[i].setProperty(hmUI.prop.MORE, {
                x: x_arr[i],
                y: y_arr[i],
                w: 35,
                h: 35,
                normal_color: i == mod - 1 ? 0x0000ff : num_arr[i] < max && max > elements.indexOf(elements_Select[i]) || nickName == "flvluju"  ? 0x00ff00 : 0xff0000
              })
             }
          } else {
            hmUI.showToast({
              text: `在游戏中达到 ${elements_Select[i]} 以解锁 ${elements_Select[i]} 的能力`
            })
            text_mod.setProperty(hmUI.prop.MORE,{
              text: "         还没解锁哦😉"
            })
          }
        },
      });
      bts.push(bt)
    }
     },
      onInit: function () {
        console.log("index page.js on init invoke");
        this.init_view();
      },
      onReady: function () {
        console.log("index page.js on ready invoke");
      },
      onShow: function () {
        console.log("index page.js on show invoke");
      },
      onHide: function () {
        console.log("index page.js on hide invoke");
      },
      onDestory: function () {
        console.log("index page.js on destory invoke"),
          hmApp.unregisterGestureEvent();
      },
    });
  })();
} catch (f) {
  console.log(f);
}

