try {
  (function () {
    var f = __$$hmAppManager$$__.currentApp,
      F = f.current;
    new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(f, F),
      "drink",
    );
    DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
    F.module = DeviceRuntimeCore.Page({
      init_view() {
    hmUI.setLayerScrolling(false);
                hmApp.unregisterGestureEvent();
    if(hmFS.SysProGetInt('element_max') == undefined){
      hmFS.SysProSetInt('element_max', 0)
    }
    if(hmFS.SysProGetInt('antival') == undefined){
      hmFS.SysProSetInt('antival', 5)
    }
    if(hmFS.SysProGetInt('antival2') == undefined){
      hmFS.SysProSetInt('antival2', 5)
    }
    var text_1 = ""
    var text_2 = ""
    var arg_1 = hmFS.SysProGetChars('data')
    if (arg_1 == undefined) {
      hmFS.SysProSetChars('data', false)
      text_1 = "经典模式 新一局"
    }
    var arg_2 = hmFS.SysProGetChars('data2')
    if (arg_2 == undefined) {
      hmFS.SysProSetChars('data2', false)
      text_2 = "限时模式 新一局"
    }
    if (arg_1 == "false") {
      text_1 = "经典模式 新一局"
    }else{
      text_1 = "经典模式 继续"
    }
    if (arg_2 == "false") {
      text_2 = "限时模式 新一局"
    }else{
      text_2 = "限时模式 继续"
    }
    hmUI.createWidget(hmUI.widget.FILL_RECT, {
      x: 0,
      y: 0,
      w: 194,
      h: 492,
      color: 0x682830
  })
  hmUI.createWidget(hmUI.widget.IMG, {
    x: 48,
    y: 10,
    w: 100,
    h: 100,
    src: "atomas.png",
  })
   hmUI.createWidget(hmUI.widget.BUTTON, {
      x: 0,
      y: 318,
      w: 194,
      h: 50,
      text: text_1,
      text_size: 30,
      color: 0x050800,
      press_color: 0xd4d5d6,
      normal_color: 0xc3c4c5,
      click_func: function () {
        hmApp.gotoPage({ url: "page/ATOMAS", param: "..." });
      },
    });
    hmUI.createWidget(hmUI.widget.BUTTON, {
      x: 0,
      y: 182,
      w: 194,
      h: 50,
      text: `商店`,
      text_size: 30,
      color: 0x050800,
      press_color: 0xd4d5d6,
      normal_color: 0xc3c4c5,
      click_func: function () {
        hmApp.gotoPage({ url: "page/ATOMAS Mods", param: "..." });
      },
    });
  hmUI.createWidget(hmUI.widget.BUTTON, {
      x: 0,
      y: 250,
      w: 194,
      h: 50,
      text: text_2,
      text_size: 24,
      color: 0x050800,
      press_color: 0xd4d5d6,
      normal_color: 0xc3c4c5,
      click_func: function () {
        hmApp.gotoPage({ url: "page/ATOMAS timer", param: "..." });
      },
    });
     },
      onInit: function () {
        console.log("index page.js on init invoke");
        this.init_view();
      },
      onReady: function () {
        console.log("index page.js on ready invoke");
      },
      onShow: function () {
        console.log("index page.js on show invoke");
      },
      onHide: function () {
        console.log("index page.js on hide invoke");
      },
      onDestory: function () {
        console.log("index page.js on destory invoke"),
          hmApp.unregisterGestureEvent();
      },
    });
  })();
} catch (f) {
  console.log(f);
}

