try {
  (function () {
    var f = __$$hmAppManager$$__.currentApp,
      F = f.current;
    new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(f, F),
      "drink",
    );
    DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
    F.module = DeviceRuntimeCore.Page({
      init_view() {
        hmUI.setLayerScrolling(false);
        const max_save = hmFS.SysProGetInt('element_max')
        var max_element = 2
        var max_circle = 12
        var is_more = 0
        var score = 0
        var asset = "no_2.png"
        var s_asset = "no_2_b.png"
        var rad_minus = 35
        var plus_num = 0
        var state_v = 0
        var life_widgets = []
        var destroy = 0
        				var mod1 = 750
				var mod2 = 1500
				var mod3 = 2000
        //Periodic Table elements
        var mod = hmFS.SysProGetInt('element_mod')
        const elements = ["H", "He", "Li", "Be", "B", "C", "N", "O", "F", "Ne", "Na", "Mg", "Al", "Si", "P", "S", "Cl", "Ar", "K",
            "Ca", "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn", "Ga", "Ge", "As", "Se", "Br", "Kr", "Rb", "Sr", "Y", "Zr",
            "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd", "In", "Sn", "Sb", "Te", "I", "Xe", "Cs", "Ba", "La", "Ce", "Pr", "Nd", "Pm",
            "Sm", "Eu", "Gd", "Tb", "Dy", "Ho", "Er", "Tm", "Yb", "Lu", "Hf", "Ta", "W", "Re", "Os", "Ir", "Pt", "Au", "Hg", "Tl", "Pb",
            "Bi", "Po", "At", "Rn", "Fr", "Ra", "Ac", "Th", "Pa", "U", "Np", "Pu", "Am", "Cm", "Bk", "Cf", "Es", "Fm", "Md", "No", "Lr",
            "Rf", "Db", "Sg", "Bh", "Hs", "Mt", "Ds", "Rg", "Cn", "Uut", "Fi", "Uup", "Lv", "Uus", "Uuo"]
        var signes = ["+", "+", "+", "-", "-"]
        var p = 0
        var next_s = 0
        if (mod == 1) {
            signes = ["+", "+", "+", "+", "+", "+", "+", "-", "-", "-"]
        } else if (mod == 2) {
            signes = ["+", "+", "+", "+", "+", "-", "-", "-", "-", "-"]
        } else if (mod == 3) {
            signes = ["+", "+", "+", "+", "+", "+", "+", "+", "-", "-"]
        } else if (mod == 4) {
            next_s = 1
        } else if (mod == 7) {
            p = 9
        }
        var game_started = false
        var data = []
        //get element randomly
        function get_Element(max = 3) {
            if (max < 3) {
                max = 3
            }
            let pls = 0
            if (next_s == 1 && Math.ceil(Math.random() * 3) == 3) {
                pls = 1
            }
            let j = elements[Math.floor(Math.random() * max) + pls + p];
            return j
        }
        //get random signe
        function get_Signe() {
            let j = signes[Math.floor(Math.random() * signes.length)];
            return j
        }
        var current_element = ""
        if (Math.floor(Math.random() * 4) > 2) {
            if (Math.floor(Math.random() * 20) < 4 && score > mod1) {
                current_element = "O+O"
            } else if (Math.floor(Math.random() * 20) > 17 && score > mod2) {
                current_element = "GET"
            } else if (Math.floor(Math.random() * 10) > 4 && Math.floor(Math.random() * 10) < 8 && score > mod3) {
                current_element = "anti"
            } else {
                current_element = "+"
            }
        } else {
            current_element = get_Element(max_element)
        }
        var length = 5
        hmUI.createWidget(hmUI.widget.FILL_RECT, {
            x: 0,
            y: 0,
            w: 194,
            h: 492,
            color: 0x682830
        })
        const centre_UI = hmUI.createWidget(hmUI.widget.CIRCLE, {
            center_x: 99,
            center_y: 184,
            color: 0x561a21,
            radius: 82
        })
        var arg = hmFS.SysProGetChars('data')
        if (arg != "false" && arg.length > 0) {
            data = arg.split(',')
            length = data.length
            score = hmFS.SysProGetInt('SCORE')
            current_element = hmFS.SysProGetChars('current')
            console.log("data_get: " + data)
        }
        var x_start = 82
        var y_start = 169
        var rad = 82
        //create a cirecunference with parameters indication, cx means center x and cy means center y
        function createCircumference(radius, cx, cy, segments, xy) {
            var vertices_x = [];
            var vertices_y = [];
            var segment = Math.PI / segments * 2;

            for (var index = 0; index < segments; index++) {
                vertices_x.push(radius * Math.cos(index * segment) + cx)
                vertices_y.push(radius * Math.sin(index * segment) + cy)
            }
            if (xy == 1) {
                return vertices_x
            } else if (xy == 2) {
                return vertices_y
            }
        }
        //create a circunference, but this is for the grey points
        function createCircumference_s(radius, cx, cy, segments, xy) {
            segments = segments * 2
            var vertices_x = [];
            var vertices_y = [];
            var segment = Math.PI / segments * 2;

            for (var index = 0; index < segments; index++) {
                if (index % 2 == 1) {
                    vertices_x.push(radius * Math.cos(index * segment) + cx)
                    vertices_y.push(radius * Math.sin(index * segment) + cy)
                }
            }
            if (xy == 1) {
                let new_arr = []
                var k = vertices_x.slice(0, vertices_x.length)
                let u = k[vertices_x.length - 1]
                for (let i = 1; i < length; i++) {
                    new_arr[i] = k[i - 1]
                }
                new_arr[0] = u
                return new_arr
            } else if (xy == 2) {
                let new_arr = []
                var k = vertices_y.slice(0, vertices_y.length)
                let u = k[vertices_y.length - 1]
                for (let i = 1; i < length; i++) {
                    new_arr[i] = k[i - 1]
                }
                new_arr[0] = u
                return new_arr
            }
            //We return the result, but as a special way, and just for my interest of chain machanics,
            //the first arr is data of 0, the second of one..., but the 0 have now data of last
        }
        var widgets = []
        var pressors = []
        init_UI(true)
        // create UI circunferences
        function init_UI(modify) {
            if(current_element == "-" && game_started == true){
                let arr_x_circle = createCircumference(rad, x_start, y_start, length, 1)
                let arr_y_circle = createCircumference(rad, x_start, y_start, length, 2)
                circle_select.setProperty(hmUI.prop.VISIBLE, true)
                console.log("state_v: " + state_v)
                circle_select.setProperty(hmUI.prop.MORE, {
                    x: arr_x_circle[state_v] - 4,
                    y: arr_y_circle[state_v] - 4
                })
            }
            if (current_element != "-" || current_element == "-" && game_started == false) {
                let arr_x = createCircumference(rad, x_start, y_start, data.length, 1)
                let arr_y = createCircumference(rad, x_start, y_start, data.length, 2)
                data = data.filter(date => date != 0)
                data = data.filter(date => date != "")
                data = data.filter(date => date != undefined)
                let j = data.length
                if (game_started == false) {
                    j = length
                    arr_x = createCircumference(rad, x_start, y_start, j, 1)
                    arr_y = createCircumference(rad, x_start, y_start, j, 2)
                }
                for (let i = 0; i < j; i++) {
                    let el = get_Element()
                    if (modify == true && arg == "false" && arg.length > 0) {
                        data.push(el)
                        console.log("create: " + el)
                    }
                    if (game_started == false) {
                        let img = hmUI.createWidget(hmUI.widget.IMG, {
                            x: arr_x[i],
                            y: arr_y[i],
                            src: data[i] + ".png"
                        })
                        widgets.push(img)
                    } else {
                        try {
                            widgets[i].setProperty(hmUI.prop.VISIBLE, true)
                            widgets[i].setProperty(hmUI.prop.MORE, {
                                x: arr_x[i],
                                y: arr_y[i],
                                src: data[i] + ".png"
                            });
                        } catch (e) {
                            let new_widget = hmUI.createWidget(hmUI.widget.IMG, {
                                x: arr_x[i],
                                y: arr_y[i],
                                src: data[i] + ".png"
                            });
                            widgets.push(new_widget);
                        }
                    }
                }
            }
            start_game()
        }
        var center = hmUI.createWidget(hmUI.widget.IMG, {
            x: 82,
            y: 169,
            src: current_element + ".png"
        })
        //grey circule UI creation
        function start_game() {
            if (length < 9) {
                asset = "no_2.png"
                s_asset = "no_2_b.png"
                rad_minus = 35
                plus_num = 0
            } else if (length > 8 && length < 13) {
                asset = "no_1.png"
                s_asset = "no_1_b.png"
                rad_minus = 30
                plus_num = 2.25
            } else if (length > 12) {
                asset = "no.png"
                s_asset = "no_b.png"
                rad_minus = 25
                plus_num = 5
            }
            let arr_x = createCircumference_s(rad - rad_minus, x_start + plus_num, y_start + plus_num, data.length, 1)
            let arr_y = createCircumference_s(rad - rad_minus, x_start + plus_num, y_start + plus_num, data.length, 2)
            data = data.filter(date => date != 0)
            data = data.filter(date => date != "")
            data = data.filter(date => date != undefined)
            let j = data.length
            if (game_started == false) {
                j = length
            }
            for (let i = 0; i < j; i++) {
                if (current_element != "-" || current_element == "-" && game_started == false) {
                    if (game_started == false) {
                        let img = hmUI.createWidget(hmUI.widget.IMG, {
                            x: arr_x[i],
                            y: arr_y[i],
                            src: i != state_v ? asset : s_asset
                        })
                        img.addEventListener(hmUI.event.CLICK_DOWN, () => {
                            Rotate(i)
                        })
                        pressors.push(img)
                    } else {
                        try {
                            console.log("modify")
                            pressors[i].setProperty(hmUI.prop.VISIBLE, true)
                            pressors[i].setProperty(hmUI.prop.MORE, {
                                x: arr_x[i],
                                y: arr_y[i],
                                src: i != state_v ? asset : s_asset
                            });
                            pressors[i].addEventListener(hmUI.event.CLICK_DOWN, () => {
                                Rotate(i)
                            })
                        } catch (e) {
                            console.log("new")
                            let new_widget = hmUI.createWidget(hmUI.widget.IMG, {
                                x: arr_x[i],
                                y: arr_y[i],
                                src: i != state_v ? asset : s_asset
                            });
                            new_widget.addEventListener(hmUI.event.CLICK_DOWN, () => {
                                Rotate(i)
                            })
                            pressors.push(new_widget);
                        }
                    }
                }
            }
            game_started = true
        }
        function aprox(num) {
            if (num % 2 == 0) {
                return Math.floor(num)
            } else {
                return Math.ceil(num)
            }
        }
        function Rotate(state) {
            destroy++
            console.log(state)
            let element = current_element
            console.log(data)
            let rest_1 = data.slice(0, state)
            let rest_2 = data.slice(state, length + 1)
            console.log(rest_1)
            if (current_element != "-") {
                rest_1.push(element)
            }
            for (let i = 0; i < rest_2.length; i++) {
                rest_1.push(rest_2[i])
            }
            let final = rest_1
            data = final
            //The game objective is to make elements reaction, so this will test symetric on both sides when element + is pleased
            if (current_element == "+") {
                var to_proton = 0
                is_more = 0
                let can = true
                let num = 0
                let k = 0
                let first_element = data[state + 1]
                let primary_element = data[state]
                console.log("first_element: " + data[state])
                //data[state] will be always +
                let new_element = first_element
                function test_more(val) {
                    // this will return if the current chain reaction elements are +, becaouse + can not react
                    if (val > 0 && data[state + val] != "+" && data[state - val] != "+") {
                        return true
                    } else if (val == 0) {
                        return true
                    } else if (val > 0 && data[state + val] == "+" && data[state - val] == "+") {
                        to_proton = 1
                        return false
                    }
                }
                let num_d = state
                let num_u = state
                for (let i = 0; i < length; i++) {
                    num++

                    if (can == true) {
                        // if next and previous elements arent equal, + will be setted on gameboard
                        if (i == 0) {
                            if (data[state + 1] != data[state - 1]) {
                                console.log("data1 is no data2")
                                k = 1
                                let element = "+"
                                console.log(data)
                                let rest_1 = data.slice(0, state)
                                let rest_2 = data.slice(state, length + 1)
                                console.log(rest_1)
                                if (current_element != "-") {
                                    rest_1.push(element)
                                }
                                for (let i = 0; i < rest_2.length; i++) {
                                    rest_1.push(rest_2[i])
                                }
                                let final = rest_1
                                console.log("data_no_char: " + data)
                                for (let i = 0; i < length; i++) {
                                    widgets[i].setProperty(hmUI.prop.VISIBLE, false)

                                }
                                for (let i = 0; i < pressors.length; i++) {
                                    pressors[i].setProperty(hmUI.prop.VISIBLE, false)

                                }


                                length = data.length
                            } else {
                                data[state] = 0
                            }
                        }
                        //symetrical test
                        if (i != 0) {
                            num_u++
                            num_d--
                        }

                        //You were true but some number have to been added
                        if (num_u == data.length) {
                            num_u = 0
                            //to be equal to las element of the data array
                        }
                        if (num_d == - 1) {
                            num_d = data.length - 1
                            //to be equal to first element of the data array
                        }
                        let u = data[num_u]
                        let d = data[num_d]
                        console.log("data1:" + data[num_u])
                        console.log("data2:" + data[num_d])
                        console.log("data1_num:" + num_u)
                        console.log("data2_num:" + num_d)
                        if (u == d && num_d != num_u && can == true && test_more(i) == true && elements.indexOf(u) != -1 && elements.indexOf(d) != -1) {
                            //Generatión of new element
                            console.log("true chain")
                            data[num_u] = 0
                            data[num_d] = 0
                            let back = new_element
                            if (i != 0) {
                                let pls_b = 1
                                if (mod == 6 && Math.floor(Math.random() * 100) > 35) {
                                    pls_b = 2
                                }
                                if (elements.indexOf(u) <= elements.indexOf(first_element) && elements.indexOf(d) <= elements.indexOf(first_element)) {
                                    console.log("minus && equal")
                                    new_element = elements[elements.indexOf(new_element) + 1]
                                    console.log("new:" + new_element)
                                    score += elements.indexOf(new_element) + pls_b
                                } else if (elements.indexOf(u) > elements.indexOf(first_element) && elements.indexOf(d) > elements.indexOf(first_element)) {
                                    console.log("more")
                                    new_element = elements[elements.indexOf(d) + elements.indexOf(first_element)]
                                    console.log("new:" + new_element)
                                    score += elements.indexOf(new_element) + pls_b
                                }
                                if (mod == 5) {
                                    score += 0.20 * elements.indexOf(new_element) + 1
                                }
                                if (back <= new_element) {
                                    console.log("remaking element")
                                    new_element = elements[elements.indexOf(new_element) + pls_b]
                                }
                                console.log("first_element: " + elements.indexOf(first_element))
                                console.log("u_element: " + elements.indexOf(u))
                                console.log("d_element: " + elements.indexOf(d))
                                console.log("data_modify: " + data)
                            }
                        } else if (i != 0) {
                            console.log("state: " + state)
                            console.log("k: " + k)
                            console.log("num: " + num)
                            console.log("false chain")
                            can = false
                        }
                    }
                }
                if (k == 0) {
                    for (let i = 0; i < length; i++) {
                        widgets[i].setProperty(hmUI.prop.VISIBLE, false)

                    }
                    for (let i = 0; i < pressors.length; i++) {
                        pressors[i].setProperty(hmUI.prop.VISIBLE, false)

                    }


                    console.log("to_proton: " + to_proton)
                    //some fixes
                    if (data[state + 1] != "+" && data[state - 1] != "+") {
                        console.log("convert to new")
                        data[state] = elements[elements.indexOf(new_element)]
                    } else {
                        data[state] = primary_element
                    }
                    //we delete of data array all elements that are 0
                    data = data.filter(date => date != 0)
                    data = data.filter(date => date != "")
                    data = data.filter(date => date != undefined);
                    length = data.length
                    let inspect = []
                    //We give a numeric value to each element of data
                    for (let k = 0; k < data.length; k++) {
                        if (data[k] != "+") {
                            inspect.push(elements.indexOf(data[k]))
                        } else if (data[k] == "+") {
                            inspect.push(-5)
                        }
                    }
                    // we set the new maximum element in case there is anew one
                    console.log("data_resul_+: " + data)
                    console.log("inspect: " + inspect)
                    max_element = Math.max(...inspect)
                    console.log("max_element_num: " + max_element)
                    console.log("max_element_simbol: " + elements[max_element])
                    console.log("data_actual_more_new:" + data)
                }
            }
            // need improve
            if (current_element == "O+O") {
                let num_u = state + 1
                let num_d = state - 1
                if (num_u == data.length) {
                    num_u = 0
                    //to be equal to las element of the data array
                }
                if (num_d == - 1) {
                    num_d = data.length - 1
                    //to be equal to first element of the data array
                }
                let u = data[num_u]
                let d = data[num_d]
                data[state] = 0
                let new_element
                if (elements.indexOf(u) < elements.indexOf(d)) {
                    console.log("minus && equal")
                    let result = elements.indexOf(u) + (elements.indexOf(u) - elements.indexOf(d))
                    new_element = elements[result]
                    console.log("new:" + new_element)
                    console.log("result: " + result)
                    score += result
                } else if (elements.indexOf(u) > elements.indexOf(d)) {
                    console.log("more")
                    let result = elements.indexOf(u) + (elements.indexOf(u) - elements.indexOf(d))
                    new_element = elements[result]
                    console.log("new:" + new_element)
                    console.log("result: " + result)
                    score += result
                } else if (elements.indexOf(u) == elements.indexOf(d)) {
                    console.log("more")
                    let result = elements.indexOf(u) + (elements.indexOf(u) - elements.indexOf(d))
                    new_element = elements[result]
                    console.log("new:" + new_element)
                    console.log("result: " + result)
                    score += result
                }
                for (let i = 0; i < length; i++) {
                    widgets[i].setProperty(hmUI.prop.VISIBLE, false)

                }
                for (let i = 0; i < pressors.length; i++) {
                    pressors[i].setProperty(hmUI.prop.VISIBLE, false)

                }
                data[state] = elements[elements.indexOf(new_element)]
                let new_arr = []
                console.log("data_actual_more:" + data)
                for (let i = 0; i < data.length; i++) {
                    if (data[i] != 0) {
                        new_arr.push(data[i])
                    }
                }
                data = new_arr
                let inspect = []
                for (let k = 0; k < data.length; k++) {
                    inspect.push(elements.indexOf(data[k]))
                }
                console.log("inspect: " + inspect)
                max_element = Math.max(...inspect)
                console.log("max_element_num: " + max_element)
                console.log("max_element_simbol: " + elements[max_element])
                console.log("data_actual_more_new:" + data)
                length = data.length
            }
            // anti will remove more or less a 50 % of elements in gameboard
            if (current_element == "anti") {
                let num_d = state
                let num_u = state
                console.log("anti_anal: " + aprox(length / 4))
                for (let i = 0; i < aprox(length / 4); i++) {
                    if (i != 0) {
                        num_u++
                        num_d--
                    }
                    if (num_u == data.length) {
                        num_u = 0
                        //to be equal to las element of the data array
                    }
                    if (num_d == - 1) {
                        num_d = data.length - 1
                        //to be equal to first element of the data array
                    }
                    console.log("data1:" + data[num_u])
                    console.log("data2:" + data[num_d])
                    console.log(true)
                    data[num_u] = 0
                    data[num_d] = 0
                }
                for (let i = 0; i < length; i++) {
                    widgets[i].setProperty(hmUI.prop.VISIBLE, false)
                }
                for (let i = 0; i < pressors.length; i++) {
                    pressors[i].setProperty(hmUI.prop.VISIBLE, false)
                }
                let new_arr = []
                console.log("data_actual_more:" + data)
                data[state] = 0
                for (let i = 0; i < data.length; i++) {
                    if (data[i] != 0) {
                        new_arr.push(data[i])
                    }
                }
                data = new_arr
                console.log("max_element_num: " + max_element)
                console.log("max_element_simbol: " + elements[max_element])
                console.log("data_actual_more_new:" + data)
                length = data.length
            }
            //some improves 
            if (current_element != "-" && current_element != "GET") {
                if (current_element != "+" && current_element != "O+O" && current_element != "anti") {
                    for (let i = 0; i < length; i++) {
                        widgets[i].setProperty(hmUI.prop.VISIBLE, false)

                    }
                    for (let i = 0; i < pressors.length; i++) {
                        pressors[i].setProperty(hmUI.prop.VISIBLE, false)

                    }
                    //This functions that ir in second if condicional:
                    // if (current_element != "+" && current_element != "O+O" && current_element != "anti") {)
                    //generally remove elements
                    length++
                }
                if (max_element > max_save) {
                    hmFS.SysProSetInt('element_max', max_element)
                }
                if (destroy == 50 && mod == 10) {
                    let j = Math.floor(Math.random() * data.length)
                    destroy = 0
                    data[j] = "no"
                    console.log("data_minus:" + data)
                    let rest_1 = []
                    //now we remove the selected element of data array
                    for (let i = 0; i < data.length; i++) {
                        if (data[i] != "no") {
                            rest_1.push(data[i])
                        }
                    }
                    console.log("rest:" + rest_1)
                    data = rest_1
                    for (let i = 0; i < length; i++) {
                        widgets[i].setProperty(hmUI.prop.VISIBLE, false)
                    }

                    length = data.length
                    if (length > 17) {
                        test_lifes()
                    } else {
                        for (let i = 0; i < life_widgets.length; i++) {
                            try {
                                life_widgets[i].setProperty(hmUI.prop.VISIBLE, false)
                            } catch (e) {
                                console.log("trying to set property on undefined :(")
                            }
                        }
                    }
                }
                if (data.length == 0 && mod == 11) {
                    score *= 2
                    update_score()
                }
                if (data.indexOf("+") != -1) {
                    console.log("more test making")
                    more_test()
                }
                init_UI(false)
            }
            //next elements selection
            if (Math.floor(Math.random() * 4) > 2) {
                if (Math.floor(Math.random() * 20) < 4 && score > mod1) {
                    current_element = "O+O"
                } else if (Math.floor(Math.random() * 20) > 17 && score > mod2) {
                    current_element = "GET"
                } else if (Math.floor(Math.random() * 10) > 4 && Math.floor(Math.random() * 10) < 8 && score > mod3) {
                    current_element = get_Signe()
                } else {
                    current_element = get_Signe()
                }
            } else {
                current_element = get_Element(max_element)
                is_more++
            }
            if (mod == 8 && length == 18 && Math.ceil(Math.random() * 3) > 3) {
                current_element = "+"
            }
            if (mod == 9 && length == 18 && Math.ceil(Math.random() * 3) > 3) {
                current_element = "-"
            }
            if (mod == 12 && length >= 18 && Math.ceil(Math.random() * 3) > 3) {
                current_element = "+"
            }
            //+ apparition fix obligation
            if (is_more > 10) {
                console.log("more time")
                current_element = "+"
            }
            console.log("selected_element:" + current_element)
            center.setProperty(hmUI.prop.MORE, {
                x: 82,
                y: 169,
                src: current_element + ".png"
            })
            update_score()
            test_minus()
            test_GET()
            if (length > 17) {
                test_lifes()
            } else {
                for (let i = 0; i < life_widgets.length; i++) {
                    try {
                        life_widgets[i].setProperty(hmUI.prop.VISIBLE, false)
                    } catch (e) {
                        console.log("trying to set property on undefined :(")
                    }
                }
            }
            data = data.filter(date => date != 0);
            data = data.filter(date => date != "")
            data = data.filter(date => date != undefined)
            save()
        }
        function save() {
        state_v = data.length - 1
            hmFS.SysProSetChars('data', data)
            hmFS.SysProSetChars('current', current_element)
            hmFS.SysProSetInt('SCORE', score)
            console.log(hmFS.SysProGetChars('data'))
            let arr = hmFS.SysProGetChars('data').split(',');
            console.log("arr: " + arr)
            arr.forEach(element => {
                console.log(element)
            });
        }

        //need improve, it will test + does dont react when they was placed
        function more_test() {
            for (let i = 0; i < length; i++) {
                if (data[i] == "+") {
                    let state = i
                    let to_proton = 0
                    is_more = 0
                    let can = true
                    let num = 0
                    let k = 0
                    let first_element = data[state + 1]
                    let primary_element = data[state]
                    console.log("first_element: " + data[state])
                    let new_element = first_element
                    function test_more(val) {
                        if (val > 0 && data[state + val] != "+" && data[state - val] != "+") {
                            return true
                        } else if (val == 0) {
                            return true
                        } else if (val > 0 && data[state + val] == "+" && data[state - val] == "+") {
                            to_proton = 1
                            return false
                        }
                    }
                    let num_d = state
                    let num_u = state
                    for (let i = 0; i < length; i++) {
                        num++
                        if (can == true) {
                            // if next and previous elements arent equal, + will be setted on gameboard
                            if (i == 0) {
                                if (data[state + 1] != data[state - 1]) {
                                    data[state] = "+"
                                    k = 1
                                } else {
                                    data[state] = 0
                                }
                            }
                            //symetrical test
                            if (i != 0) {
                                num_u++
                                num_d--
                            }
                            //You were true but some number have to been added
                            if (num_u == data.length) {
                                num_u = 0
                                //to be equal to las element of the data array
                            }
                            if (num_d == - 1) {
                                num_d = data.length - 1
                                //to be equal to first element of the data array
                            }
                            let u = data[num_u]
                            let d = data[num_d]
                            console.log("data1:" + data[num_u])
                            console.log("data2:" + data[num_d])
                            console.log("data1_num:" + num_u)
                            console.log("data2_num:" + num_d)
                            if (u == d && can == true && test_more(i) == true && elements.indexOf(u) != -1 && elements.indexOf(d) != -1) {
                                console.log("true chain")
                                data[num_u] = 0
                                data[num_d] = 0
                                if (i != 0) {
                                    if (elements.indexOf(u) <= elements.indexOf(first_element) && elements.indexOf(d) <= elements.indexOf(first_element)) {
                                        console.log("minus && equal")
                                        new_element = elements[elements.indexOf(new_element) + 1]
                                        console.log("new:" + new_element)
                                        score += elements.indexOf(new_element) + 1
                                    } else if (elements.indexOf(u) > elements.indexOf(first_element) && elements.indexOf(d) > elements.indexOf(first_element)) {
                                        console.log("more")
                                        new_element = elements[elements.indexOf(d) + elements.indexOf(first_element)]
                                        console.log("new:" + new_element)
                                        score += elements.indexOf(new_element) + 1
                                    }
                                    console.log("first_element: " + elements.indexOf(first_element))
                                    console.log("u_element: " + elements.indexOf(u))
                                    console.log("d_element: " + elements.indexOf(d))
                                    console.log("data_modify: " + data)
                                }
                            } else if (i != 0) {
                                console.log("state: " + state)
                                console.log("k: " + k)
                                console.log("num: " + num)
                                console.log("false chain")
                                can = false
                            }
                        }
                    }
                    if (k == 0) {
                        try {
                            for (let i = 0; i < length; i++) {
                                widgets[i].setProperty(hmUI.prop.VISIBLE, false)

                            }
                            for (let i = 0; i < pressors.length; i++) {
                                pressors[i].setProperty(hmUI.prop.VISIBLE, false)

                            }


                        } catch (d) {
                            console.log(d)
                        }
                        console.log("to_proton: " + to_proton)
                        if (data[state + 1] != "+" && data[state - 1] != "+") {
                            console.log("convert to new")
                            data[state] = elements[elements.indexOf(new_element)]
                        } else {
                            data[state] = "+"
                        }
                        data = data.filter(date => date != 0)
                        data = data.filter(date => date != "")
                        data = data.filter(date => date != undefined);
                        length = data.length
                        let inspect = []
                        for (let k = 0; k < data.length; k++) {
                            if (data[k] != "+") {
                                inspect.push(elements.indexOf(data[k]))
                            } else if (data[k] == "+") {
                                inspect.push(-5)
                            }
                        }
                        console.log("data_resul_+: " + data)
                        console.log("inspect: " + inspect)
                        max_element = Math.max(...inspect)
                        console.log("max_element_num: " + max_element)
                        console.log("max_element_simbol: " + elements[max_element])
                        console.log("data_actual_more_new:" + data)
                    }
                }
            }
        }
        function test_lifes() {
            let img_wh = 20
            let num = 0
            let max_length = Math.abs(20 - data.length - 3)
            for (let i = 0; i < life_widgets.length; i++) {
                try {
                    life_widgets[i].setProperty(hmUI.prop.VISIBLE, false)
                } catch (e) {
                    console.log("trying to set property on undefined :(")
                }
            }
            if (num <= max_length) {
                for (let i = data.length; i < 21; i++) {
                    let life_img = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 174,
                        y: 25 + (img_wh * (num + 1)) + 20,
                        src: `life_${num + 1}.png`
                    })
                    num += 1
                    life_widgets.push(life_img)
                }
            }
            if (data.length > 20) {
                game_over()
            }
        }
        //score UI generation and set
        const score_TEXT = hmUI.createWidget(hmUI.widget.TEXT, {
            x: 20,
            y: 50,
            w: 192-20-20,
            h: 70,
            text_size: 20,
            text_style: hmUI.text_style.WRAP,
            color: 0xffffff,
            text: "Score:"+score
        })
/*🚗*/        var scores = [];
        var t_Scores = String(score);
function update_score() {
							score_TEXT.setProperty(hmUI.prop.MORE, {
								text: "score:"+score
							});
				}
        
        function game_over() {
            let over_rect = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                x: 0,
                y: 0,
                w: 194,
                h: 492,
                color: 0x682830
            })
            let over_text = hmUI.createWidget(hmUI.widget.TEXT, {
                x: 10,
                y: 300,
                w: 184,
                text_size: 30,
                text: "你 亖 了",
                color: 0xffffff
            })
            let max_element_img = hmUI.createWidget(hmUI.widget.IMG, {
                x: 82,
                y: 235,
                src: elements[max_element] + ".png"
            })
            let exit_over = hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 30,
                y: 175,
                w: 134,
                h: 35,
                radius: 5,
                color: 0xffffff,
                normal_color: 0x561a21,
                press_color: 0x672b32,
                text: "离开游戏",
                click_func: function () {
                    hmFS.SysProSetChars('data', "false")
                    hmFS.SysProSetChars('current', 0)
                    hmFS.SysProSetInt('SCORE', 0)
                    hmApp.goBack()
    
                }
            })
            let retry_over = hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 30,
                y: 130,
                w: 134,
                h: 35,
                radius: 5,
                color: 0xffffff,
                normal_color: 0x561a21,
                press_color: 0x672b32,
                text: "再来一局",
                click_func: function () {
                    hmFS.SysProSetChars('data', "false")
                    hmFS.SysProSetChars('current', 0)
                    hmFS.SysProSetInt('SCORE', 0)
                    hmApp.reloadPage({ url: "page/ATOMAS", param: "..." });
    
                }
            })
            console.log("over_max_element:" + elements[max_element] + ".png")
            let scores_over = []
            let t_Scores_over = String(score);
        const score_TEXT = hmUI.createWidget(hmUI.widget.TEXT, {
            x: 20,
            y: 50,
            w: 192-20-20,
            h: 70,
            text_size: 20,
            text_style: hmUI.text_style.WRAP,
            color: 0xffffff,
            text: "Score:"+score
        })
        }
        //Copy the element selected
        function test_GET() {
            if (current_element == "GET") {
                console.log("data_try:" + data)
                for (let i = 0; i < pressors.length; i++) {
                    pressors[i].setProperty(hmUI.prop.VISIBLE, false)

                }
                for (let j = 0; j < widgets.length; j++) {
                    widgets[j].addEventListener(hmUI.event.CLICK_DOWN, () => {
                        //element selected changes now to current element or the played element

                        current_element = data[j]
                        console.log("state:" + j)
                        console.log("length:" + length)
                        console.log("minus_element:" + data[j])
                        center.setProperty(hmUI.prop.MORE, {
                            x: 82,
                            y: 169,
                            src: current_element + ".png"
                        })
                        for (let i = 0; i < length; i++) {
                            widgets[i].setProperty(hmUI.prop.VISIBLE, false)

                        }
                        if (length > 17) {
                            test_lifes()
                        } else {
                            for (let i = 0; i < life_widgets.length; i++) {
                                try {
                                    life_widgets[i].setProperty(hmUI.prop.VISIBLE, false)
                                } catch (e) {
                                    console.log("trying to set property on undefined :(")
                                }
                            }
                        }
                        init_UI(false)
                    })
                }
            }
        }
        const circle_select = hmUI.createWidget(hmUI.widget.STROKE_RECT, {
            x: 0,
            y: 0,
            w: 38,
            h: 38,
            line_width: 4,
            color: 0x0000ff,
            radius: 19
        })
        circle_select.setProperty(hmUI.prop.VISIBLE, false)
        const left = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 5,
            y: 285,
            w: 87,
            h: 35,
            radius: 5,
            color: 0xffffff,
            normal_color: 0x561a21,
            press_color: 0x672b32,
            text: "<",
            click_func: function () {
                state_v--
                if (state_v == -1) {
                    state_v = data.length - 1
                }
                if (current_element != "-") {
                    let s_asset
                    if (length < 9) {
                        s_asset = "no_2_b.png"
                    } else if (length > 8 && length < 13) {
                        s_asset = "no_1_b.png"
                    } else if (length > 12) {
                        s_asset = "no_b.png"
                    }
                    for (let i = 0; i < data.length; i++) {
                        pressors[i].setProperty(hmUI.prop.MORE, {
                            src: i == state_v ? s_asset : asset
                        })
                        circle_select.setProperty(hmUI.prop.VISIBLE, false)
                    }
                } else {
                    let arr_x = createCircumference(rad, x_start, y_start, length, 1)
                    let arr_y = createCircumference(rad, x_start, y_start, length, 2)
                    circle_select.setProperty(hmUI.prop.VISIBLE, true)
                    console.log("state_v: " + state_v)
                    circle_select.setProperty(hmUI.prop.MORE, {
                        x: arr_x[state_v] - 4,
                        y: arr_y[state_v] - 4
                    })
                }
            }
        })
        const right = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 102,
            y: 285,
            w: 87,
            h: 35,
            radius: 5,
            color: 0xffffff,
            normal_color: 0x561a21,
            press_color: 0x672b32,
            text: ">",
            click_func: function () {
                state_v++
                if (state_v == data.length) {
                    state_v = 0
                }
                if (current_element != "-") {
                    circle_select.setProperty(hmUI.prop.VISIBLE, false)
                    if (length < 9) {
                        s_asset = "no_2_b.png"
                    } else if (length > 8 && length < 13) {
                        s_asset = "no_1_b.png"
                    } else if (length > 12) {
                        s_asset = "no_b.png"
                    }
                    for (let i = 0; i < data.length; i++) {
                        pressors[i].setProperty(hmUI.prop.MORE, {
                            src: i == state_v ? s_asset : asset
                        })
                    }
                } else {
                    let arr_x = createCircumference(rad, x_start, y_start, length, 1)
                    let arr_y = createCircumference(rad, x_start, y_start, length, 2)
                    circle_select.setProperty(hmUI.prop.VISIBLE, true)
                    console.log("state_v: " + state_v)
                    circle_select.setProperty(hmUI.prop.MORE, {
                        x: arr_x[state_v] - 4,
                        y: arr_y[state_v] - 4
                    })
                }
            }
        })
        const launch = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 5,
            y: 325,
            w: 184,
            h: 35,
            radius: 5,
            color: 0xffffff,
            normal_color: 0x561a21,
            press_color: 0x672b32,
            text: "选择",
            click_func: function () {
                if (current_element != "-") {
                    Rotate(state_v)
                } else {
                    let j = state_v
                    current_element = data[j]
                    console.log("state:" + j)
                    console.log("length:" + length)
                    current_element = data[j]
                    console.log("minus_element:" + data[j])
                    center.setProperty(hmUI.prop.MORE, {
                        x: 82,
                        y: 169,
                        src: current_element + ".png"
                    })
                    //As the - selected elemend can be turned into a +, we add an event listener to the center
                    center.addEventListener(hmUI.event.CLICK_DOWN, () => {
                        //We change into a +
                        current_element = "+"
                        center.setProperty(hmUI.prop.MORE, {
                            x: 82,
                            y: 169,
                            src: current_element + ".png"
                        })
                        //We remove event listener of center
                        center.removeEventListener(hmUI.event.DOWN)
                        circle_select.setProperty(hmUI.prop.VISIBLE, false)
                    })
                    //As the element selected are removed
                    data[j] = "no"
                    console.log("data_minus:" + data)
                    let rest_1 = []
                    //now we remove the selected element of data array
                    for (let i = 0; i < data.length; i++) {
                        if (data[i] != "no") {
                            rest_1.push(data[i])
                        }
                    }
                    console.log("rest:" + rest_1)
                    data = rest_1
                    for (let i = 0; i < length; i++) {
                        widgets[i].setProperty(hmUI.prop.VISIBLE, false)

                    }

                    length = data.length
                    if (length > 17) {
                        test_lifes()
                    } else {
                        for (let i = 0; i < life_widgets.length; i++) {
                            try {
                                life_widgets[i].setProperty(hmUI.prop.VISIBLE, false)
                            } catch (e) {
                                console.log("trying to set property on undefined :(")
                            }
                        }
                    }
                    init_UI(false)
                    for (let i = 0; i < widgets.length; i++) {
                        widgets[i].removeEventListener(hmUI.event.DOWN)
                    }
                }
                circle_select.setProperty(hmUI.prop.VISIBLE, false)
            }
        })
        const exit = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 20,
            y: 400,
            w: 152,
            h: 45,
            radius: 5,
            color: 0xffffff,
            normal_color: 0x561a21,
            press_color: 0x672b32,
            text_size: 12,
            text: "退出",
            click_func: function () {
   
                swipe()
            }
        })

        function swipe() {
        let bg_warm = hmUI.createWidget(hmUI.widget.FILL_RECT, {
            x: 0,
            y: 0,
            w: 194,
            h: 492,
            color: 0x682830
        })
        let warm_text = hmUI.createWidget(hmUI.widget.TEXT, {
            x: 5,
            y: 50,
            w: 184,
            color: 0xffffff,
            text_size: 20,
            text_style: hmUI.text_style.WRAP,
            text: "如果退出将会丢失进度\n要保存进度，请直接右滑退出（"
        });
        let yes = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 20,
            y: 270,
            w: 154,
            h: 35,
            radius: 5,
            color: 0xffffff,
            normal_color: 0x00ff00,
            press_color: 0x00ff00,
            text: "丢掉进度😭",
            click_func: function () {
                hmFS.SysProSetChars('data', "false")
                hmFS.SysProSetChars('current', 0)
                hmFS.SysProSetInt('SCORE', 0)
                hmApp.goBack()

            }
        })
        let no = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 20,
            y: 320,
            w: 154,
            h: 35,
            radius: 5,
            color: 0xffffff,
            normal_color: 0xff0000,
            press_color: 0xff0000,
            text: "继续Van👍",
            click_func: function () {
                no.setProperty(hmUI.prop.VISIBLE, false)
                yes.setProperty(hmUI.prop.VISIBLE, false)
                warm_text.setProperty(hmUI.prop.VISIBLE, false)
                bg_warm.setProperty(hmUI.prop.VISIBLE, false)
            }
        })
        }
        const anti_widget = hmUI.createWidget(hmUI.widget.IMG, {
            x: 120,
            y: 370,
            src: "anti_m.png"
        });
        const anti_text = hmUI.createWidget(hmUI.widget.TEXT, {
            x: 100,
            y: 369,
            w: 15,
            color: 0xffffff,
            text_size: 15,
            text: String(hmFS.SysProGetInt('antival2'))
        });
        anti_widget.addEventListener(hmUI.event.CLICK_DOWN, () => {
            if (hmFS.SysProGetInt('antival') > -5) {
                current_element = "anti"
                if (hmSetting.getUserData().nickName != "FlvLujU" || hmSetting.getUserData().nickName != "") {
                    hmFS.SysProSetInt('antival', hmFS.SysProGetInt('antival') - 1)
                } else {
                    hmFS.SysProSetInt('antival', 5)
                }
                center.setProperty(hmUI.prop.MORE, {
                    x: 82,
                    y: 169,
                    src: current_element + ".png"
                })
                anti_text.setProperty(hmUI.prop.MORE, {
                    text: String(hmFS.SysProGetInt('antival'))
                })
            }
            if (hmSetting.getUserData().nickName == "FlvLujU" || hmSetting.getUserData().nickName == "") {
                hmFS.SysProSetInt('antival', 5)
            }
            anti_text.setProperty(hmUI.prop.MORE, {
                text: String(hmFS.SysProGetInt('antival'))
            })
        })
        //copy and quit the element selected from the gameboard, when the substracted element is pressed it turns into a + element
        function test_minus() {
            let arr_x = createCircumference(rad, x_start, y_start, length, 1)
            let arr_y = createCircumference(rad, x_start, y_start, length, 2)
            circle_select.setProperty(hmUI.prop.MORE, {
                x: arr_x[state_v] - 4,
                y: arr_y[state_v] - 4
            })

            if (current_element == "-") {
                circle_select.setProperty(hmUI.prop.VISIBLE, true)
                console.log("data_try:" + data)
                for (let i = 0; i < pressors.length; i++) {
                    pressors[i].setProperty(hmUI.prop.VISIBLE, false)

                }
                for (let j = 0; j < data.length; j++) {
                    //We add a event Listener for each element in gameboard
                    widgets[j].addEventListener(hmUI.event.CLICK_DOWN, () => {
                        //As each widget position match with the element in the data array

                        //We change the actual element to the widget current element value pressed
                        current_element = data[j]
                        console.log("state:" + j)
                        console.log("length:" + length)
                        current_element = data[j]
                        console.log("minus_element:" + data[j])
                        center.setProperty(hmUI.prop.MORE, {
                            x: 82,
                            y: 169,
                            src: current_element + ".png"
                        })
                        //As the - selected elemend can be turned into a +, we add an event listener to the center
                        center.addEventListener(hmUI.event.CLICK_DOWN, () => {
                            //We change into a +
                            current_element = "+"
                            center.setProperty(hmUI.prop.MORE, {
                                x: 82,
                                y: 169,
                                src: current_element + ".png"
                            })
                            //We remove event listener of center
                            circle_select.setProperty(hmUI.prop.VISIBLE, false)
                            center.removeEventListener(hmUI.event.DOWN)
                        })
                        //As the element selected are removed
                        data[j] = "no"
                        console.log("data_minus:" + data)
                        let rest_1 = []
                        //now we remove the selected element of data array
                        for (let i = 0; i < data.length; i++) {
                            if (data[i] != "no") {
                                rest_1.push(data[i])
                            }
                        }
                        console.log("rest:" + rest_1)
                        data = rest_1
                        for (let i = 0; i < length; i++) {
                            widgets[i].setProperty(hmUI.prop.VISIBLE, false)

                        }

                        length = data.length
                        if (length > 17) {
                            test_lifes()
                        } else {
                            for (let i = 0; i < life_widgets.length; i++) {
                                try {
                                    life_widgets[i].setProperty(hmUI.prop.VISIBLE, false)
                                } catch (e) {
                                    console.log("trying to set property on undefined :(")//好玩吗？？
                                }
                            }
                        }

                        init_UI(false)
                        for (let i = 0; i < widgets.length; i++) {
                            widgets[i].removeEventListener(hmUI.event.DOWN)
                        }
                        circle_select.setProperty(hmUI.prop.VISIBLE, false)
                    })
                }
            }
        }
        if (data.length > 17) {
            test_lifes()
        }
     },
      onInit: function () {
        console.log("index page.js on init invoke");
        this.init_view();
      },
      onReady: function () {
        console.log("index page.js on ready invoke");
      },
      onShow: function () {
        console.log("index page.js on show invoke");
      },
      onHide: function () {
        console.log("index page.js on hide invoke");
      },
      onDestory: function () {
        console.log("index page.js on destory invoke"),
          hmApp.unregisterGestureEvent();
      },
    });
  })();
} catch (f) {
  console.log(f);
}

