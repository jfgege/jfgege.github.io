//###########################################################################################################################################################################################
//###########################################################################################################################################################################################
//###########################################################################################################################################################################################
//#############$!!!!!!!!!!!!|&###############################################################################################################################################################
//##########$!!!!!!!!!!!!!!!!!!|@############################################################################################################################################################
//########&!!!!!!!!!!!!!!!!!!!!!!|@##########&%|!!|$#########################################################################################################################################
//#######%!!!!!!!!!!!!!!!!!!!!!!!!!&######%!!!!!!!!!!!%@#####################################################################################################################################
//######$!!!!!!!!!!!!!!!!!!!!!!!!!!!&###$!!!!!!!!!!!!!!!$###########################$!!%########################&|||||||||||&########@%!!%@#######$!!|@###########&|!!!!!!!!!!!!!!!!!$#######
//#####&|!!!!!!!!!!!!!!!!!!!!!!!!!!!%##$!!!!!!!!!!!!!!!!!$#################&|!|@##@%!!!$###%!!%@######@%!!%@###$!!!!!!!!!!!!|@#######$!!!%#######%!!!$##########%!!!!!!!!!!!!!!!!!!!!!%######
//#####$!!!!!!!!!!!!!!!!!!!!!!!!!!!!|@@%!!!!!!!!!!!!!!!!!|@################%!!!!$#&!!!!&#$!!!!%#######$!!!$#####$%||||||||%&#######@&&&$&@######@|!!!&#########%!!!!|%%%%%%%%%%%%%%%%$@######
//#####$!!!!!!!!!!!!!!!!!!!!!!!!!!!!|&@|!!!!!!!!!!!!!!!!!|&################&|!!!%@$!!!%@&!!!!&#######$!!!!|%@####################&!!!!!!!!%###&$%!!!!%$$&@####@|!!!&#@|!!&####&|!!|@#########
//#####&!!!!!!!!!!!!!!!!!!!!!!!!!!!!%@#$!!!!!!!!!!!!!!!!!%###################@&##@|!!!$############&|!!!!!!!%@@&$$$$$$$$$$$$$@###&%||!!!!!&@|!!!!!!!!!!!!$####&!!!|@#%!!!!%@&|!!!!$##########
//######%!!!!!!!!!!!!!!!!!!!!!!!!!!!&###%!!!!!!!!!!!!!!!%@##############$!!!!!!!!!!!!!!!!!!!!!!!&###&|!!!|%$%!!!!!!!!!!!!!!!!$######&!!!!&#$!!!!!!!!!!!|@#####%!!!%###%!!!!!!!!!%############
//######@%!!!!!!!!!!!!!!!!!!!!!!!!!$#####&|!!!!!!!!!!!!&###############%!!!!!!!!!!!!!!!!!!!!!!!$####@%!!|&#&|!!!!!!!!!!!!!!%######&!!!!!$######$!!!|@########@|!!!&####@|!!!!!%##############
//########$!!!!!!!!!!!!!!!!!!!!!!!&#########&|!!!!!|&##########################%!!!!!!|&############&!!!%@#####$!!!|@###########&!!!!!!!!!$####%!!!$#########$!!!|@###$!!!!!!!!$#############
//#########@%!!!!!!!!!!!!!!!!!!!$###########################################&|!!!!!!!!!!|@##########$!!!$#####%!!!%###%!!|@####&|!!!!!!!!!|@##@|!!!&#########%!!!%#&|!!!!!||!!!!|&###########
//############&|!!!!!!!!!!!!!%@####%!!!!!!!$#############################@%!!!!!!!!!!!!!!!!$#######@%!!!||$#@|!!!$###@|!!!$####&!|%!!!$@%|&###$!!!|@########@|!!!&&|!!!|&###$!!!!%###########
//#################@&$$$&@######&!!!!!!!!!!!!|@########################%!!!!!|&@|!!!$#$!!!!!!$#####%!!!!!|&&!!!!&##@&$|!!!%#######$!!!&#######%!!!%#########&!!!|@#@%$#######@||&############
//#############################$!!!!!!!!!!!!!!!&#####################@%!!!!$###&!!!!&###$!!!!%###@|!!!!!%#&|!!!!!!!!!!!!!!|&#####@|!!|@#@|!!!!!!!!!!!!!|@###%!!!!!!!!!!!!!!!!!!!!!$##########
//############################&|!!!!!!!!!!!!!!!|@#####################%!%@#####$!!!%######&!%@###@%$@######%!!!!!!!!|%%!!!!&#####&!!!%#&!!!!!!!!!!!!!!!&###@|!!!!!!!!!!!!!!!!!!!!!!%#########
//############################$!!!!!!!!!!!!!!!!|&#############################@%!|&####################################@%$########%!!&######################&%%%%%%%%%%%%%%%%%%%%%&##########
//############################@|!!!!!!!!!!!!!!!%@############################################################################################################################################
//#############################&!!!!!!!!!!!!!!|@#############################################################################################################################################
//###############################%!!!!!!!!!!!$###############################################################################################################################################
//#################################@$|!!!|$##################################################################################################################################################
//###########################################################################################################################################################################################
try {
    (() => {
      var e = __$$hmAppManager$$__.currentApp;
      var t = e.current,
        { px: o } =
          (new DeviceRuntimeCore.WidgetFactory(
            new DeviceRuntimeCore.HmDomApi(e, t)
          ),
          e.app.__globals__);
  try {
    (() => {
      var e = __$$hmAppManager$$__.currentApp,
      t = e.current;
    new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(e, t),
      "drink"
    );
  DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
  t.module = DeviceRuntimeCore.Page({
      init_view() {
        
              const isVertical = true
      hmUI.setScrollView(true, 490, 4, isVertical);
    
    const battery = hmSensor.createSensor(hmSensor.id.BATTERY)
      var bl = 0
    const groupm1 = hmUI.createWidget(hmUI.widget.GROUP,{
      x:0,
      y:980,
      w:192,
      h:490
    })
    const grouptime = hmUI.createWidget(hmUI.widget.GROUP, {
      x: 0,
      y: 0,
      w:192,
      h:490
    })
    const groupurl = hmUI.createWidget(hmUI.widget.GROUP, {
      x:0,
      y:20,
      w:192,
      h:980
    })
    const groupbg = hmUI.createWidget(hmUI.widget.GROUP, {
      x:0,
      y:1470,
      w:192,
      h:490
    })
    groupm1.createWidget(hmUI.widget.IMG,{
      x: 61,
      y: 38,
      src: "batt.png"
    })
    groupm1.createWidget(hmUI.widget.ARC, {
      x: 50,
      y: 28,
      w: 94,
      h: 94,
      start_angle: 0,
      end_angle: 360,
      color: 0x094c30,
      line_width: 10
    })
    const bg = grouptime.createWidget(hmUI.widget.IMG,{
      x: 0,
      y: 0,
      src: "bg/bg1.png"
    })
    const ARC = groupm1.createWidget(hmUI.widget.ARC, {
      x: 50,
      y: 28,
      w: 94,
      h: 94,
      start_angle: 0,
      end_angle: 0,
      color: 0x00fc8c,
      line_width: 10
    })

    const min = grouptime.createWidget(hmUI.widget.IMG, {
      x: 66,
      y: 245,
      src: "Room1-num/0.png"
      })
      
      const hour = grouptime.createWidget(hmUI.widget.IMG, {
      x: 66,
      y: 54,
      src:"Room1-num/0.png"
      })
      const minf = grouptime.createWidget(hmUI.widget.IMG, {
      x: 66,
      y: 332,
      src: "Room1-num/0.png"
      })
      
      const hourf = grouptime.createWidget(hmUI.widget.IMG, {
      x: 66,
      y: 141,
      src:"Room1-num/0.png"
      })
      grouptime.createWidget(hmUI.widget.FILL_RECT, {
        x: 19,
        y: 105,
        w: 10,
        h: 300,
        radius: 50,
        color: 0x094c30
      })  
      const batteryline = grouptime.createWidget(hmUI.widget.FILL_RECT, {
        x: 19,
        y: 105,
        w: 10,
        h: 300,
        radius: 50,
        color: 0x00fc8c
      })
        const batttext = groupm1.createWidget(hmUI.widget.IMG, {
          x: 42,
          y: 136,
          src: "warning.png"
        })
        groupm1.createWidget(hmUI.widget.IMG, {
          x: 38,
          y: 339,
          src: "miai.png"
        }).addEventListener(hmUI.event.CLICK_UP,(function(info){
          hmApp.startApp({url: "XiaoAiScreen", native: true})
        }))



    const time = hmSensor.createSensor(hmSensor.id.TIME);
const timer1 = timer.createTimer(
  500,
  1000,
  function (option) {  

    let timeminutefen, timeminute, timesecondfen, timesecond, timehourfen, timehour;
    hmSetting.setBrightScreen(10);
    batteryline.setProperty(hmUI.prop.MORE, {
      x: 19,
      y: 105,
      w: 10,
      h: battery.current * 3,
      radius: 50,
      color: 0x00fc8c
    });
    ARC.setProperty(hmUI.prop.MORE, {
      x: 50,
      y: 28,
      w: 94,
      h: 94,
      start_angle: 0,
      end_angle: 3.6 * battery.current,
      color: 0x00fc8c,
      line_width: 10
    });
    if (time.minute >= 10 && time.minute <= 19) {
      timeminutefen = "Room1-num/" + (time.minute - 10) + ".png";
      timeminute = "Room1-num/1.png";
    }
    else if (time.minute >= 20 && time.minute <= 29) {
      timeminutefen = "Room1-num/" + (time.minute - 20) + ".png";
      timeminute = "Room1-num/2.png";
    }
    else if (time.minute >= 30 && time.minute <= 39) {
      timeminutefen = "Room1-num/" + (time.minute - 30) + ".png";
      timeminute = "Room1-num/3.png";
    }
    else if (time.minute >= 40 && time.minute <= 49) {
      timeminutefen = "Room1-num/" + (time.minute - 40) + ".png";
      timeminute = "Room1-num/4.png";
    }
    else if (time.minute >= 50 && time.minute <= 59) {
      timeminutefen = "Room1-num/" + (time.minute - 50) + ".png";
      timeminute = "Room1-num/5.png";
    }
    else if (time.minute === 60) {
      timeminutefen = "Room1-num/0.png";
      timeminute = "Room1-num/6.png";
    }
    else {
      timeminutefen = "Room1-num/" + time.minute + ".png";;
      timeminute = "Room1-num/0.png";
    }

    if (time.hour >= 20) {
      timehour = "Room1-num/2.png";
      timehourfen = "Room1-num/" + (time.hour - 20) + ".png";
    }
    else if (time.hour >= 10) {
      timehour = "Room1-num/1.png";
      timehourfen = "Room1-num/" + (time.hour - 10) + ".png";
    }
    else {
      timehour = "Room1-num/0.png";
      timehourfen = "Room1-num/" + time.hour + ".png";
    }
    if (battery.current >= 30) {
      batttext.setProperty(hmUI.prop.MORE, {
        x: 42,
        y: 136,
        src: "ENOUGH.png"
    })}
    else {
      batttext.setProperty(hmUI.prop.MORE, {
        x: 42,
        y: 151,
        src: "WARN.png"
    })}
    hour.setProperty(hmUI.prop.MORE, {
      x: 66,
      y: 69,
      src: timehour
    });
    hourf.setProperty(hmUI.prop.MORE, {
      x: 66,
      y: 156,
      src: timehourfen
    });
    min.setProperty(hmUI.prop.MORE, {
      x: 66,
      y: 260,
      src: timeminute 
    });
    minf.setProperty(hmUI.prop.MORE, {
      x: 66,
      y: 347,
      src: timeminutefen
    });

    console.log('timer callback');
  },
  { hour: 0, minute: 15, second: 30 }
);

    grouptime.createWidget(hmUI.widget.IMG, {
       x: 7,
       y: 248,
       src: "battery.png"
    })


    groupurl.createWidget(hmUI.widget.FILL_RECT, {
      x: 10,
      y: 540,
      w: 172,
      h: 80,
      radius: 15,
      color: 0xffd700
    }).addEventListener(hmUI.event.CLICK_UP,(function(info){
      hmApp.startApp({url: "Settings_lightAdjustScreen", native: true})
    }))
    const url1 =  groupurl.createWidget(hmUI.widget.IMG, {
      x: 70,
      y: 562,
      src: 'url/bright.png'
    })
    url1.addEventListener(hmUI.event.CLICK_UP,(function(info){
      hmApp.startApp({url: "Settings_lightAdjustScreen", native: true})
    }))

    
    groupurl.createWidget(hmUI.widget.FILL_RECT, {
      x: 10,
      y: 632,
      w: 80,
      h: 80,
      radius: 15,
      color: 0x1c1c1c
    })//中英词典
    
    const url2 =  groupurl.createWidget(hmUI.widget.IMG, {
      x: 28,
      y: 652,
      src: 'url/dic.png'
    })
    url2.addEventListener(hmUI.event.CLICK_UP,(function(info){
      hmApp.startApp({appid:23306,url:'page/192x490_s_l66/index.page'})
    }))

    groupurl.createWidget(hmUI.widget.FILL_RECT, {
      x: 102,
      y: 632,
      w: 80,
      h: 80,
      radius: 15,
      color: 0x1c1c1c
    })//计算机
    
    const url3 =  groupurl.createWidget(hmUI.widget.IMG, {
      x: 123,
      y: 652,
      src: 'url/calc.png'
    })
    url3.addEventListener(hmUI.event.CLICK_UP,(function(info){
      hmApp.startApp({appid: 23301,url:'page/192x490_s_l66/home/index.page' })
    }))

    groupurl.createWidget(hmUI.widget.FILL_RECT, {
      x: 10,
      y: 724,
      w: 80,
      h: 80,
      radius: 15,
      color: 0x1c1c1c
    })//课程表
    
    const url4 =  groupurl.createWidget(hmUI.widget.IMG, {
      x: 28,
      y: 742,
      src: 'url/timetable.png'
    })
    url4.addEventListener(hmUI.event.CLICK_UP,(function(info){
      hmApp.startApp({appid: 23315,url:'pages/index.page'})
    }))
    groupurl.createWidget(hmUI.widget.FILL_RECT, {
      x: 102,
      y: 724,
      w: 80,
      h: 172,
      radius: 15,
      color: 0x1c1c1c
    }).addEventListener(hmUI.event.CLICK_UP,(function(info){
      hmApp.startApp({url: "PhoneMusicCtrlScreen", native: true})
    }))
    
    const url5 = groupurl.createWidget(hmUI.widget.IMG, {
      x: 123,
      y: 780,
      src: 'url/music.png'
    })
    url5.addEventListener(hmUI.event.CLICK_UP,(function(info){
      hmApp.startApp({url: "PhoneMusicCtrlScreen", native: true})
    }))

    groupurl.createWidget(hmUI.widget.FILL_RECT, {
      x: 10,
      y: 816,
      w: 80,
      h: 80,
      radius: 15,
      color: 0x00fc8c
    })
    
    const url6 =  groupurl.createWidget(hmUI.widget.IMG, {
      x: 30,
      y: 835,
      src: 'url/exit.png'
    })
    url6.addEventListener(hmUI.event.CLICK_UP,(function(info){
      hmSetting.setBrightScreenCancel()
      hmApp.goBack()
    }))



    groupbg.createWidget(hmUI.widget.IMG,{
      x: 56,
      y: 150,
      src: "bg/1.png"
    }).addEventListener(hmUI.event.CLICK_UP,(function(info){
      bg.setProperty(hmUI.prop.MORE, {
        x: 0,
        y: 0,
        src:"bg/bg1.png"
      }) 
      }));
    groupbg.createWidget(hmUI.widget.IMG,{
      x: 56,
      y: 250,
      src: "bg/2.png"
    }).addEventListener(hmUI.event.CLICK_UP,(function(info){
      bg.setProperty(hmUI.prop.MORE, {
        x: 0,
        y: 0,
        src:"bg/bg2.png" 
      });
    }))
    groupbg.createWidget(hmUI.widget.IMG,{
      x: 56,
      y: 350,
      src: "bg/3.png"
    }).addEventListener(hmUI.event.CLICK_UP,(function(info){
      bg.setProperty(hmUI.prop.MORE, {
        x: 0,
        y: 0,
        src:"bg/bg3.png" 
      });
    }))





      },
      onInit() {
        console.log("index page.js on init invoke"), this.init_view();
      },
      onReady() {
        console.log("index page.js on ready invoke");
      },
      onShow() {
        console.log("index page.js on show invoke");
      },
      onHide() {
        console.log("index page.js on hide invoke");
      },
      onDestory() {
        console.log("index page.js on destory invoke");
      }
    });
  })();
  } catch (e) {
  console.log(e);
  }
  })();
  } catch (e) {
  console.log(e);
  }