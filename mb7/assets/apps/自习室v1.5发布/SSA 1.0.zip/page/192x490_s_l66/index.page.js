try {
  (() => {
    var e = __$$hmAppManager$$__.currentApp;
    var t = e.current,
      { px: o } =
        (new DeviceRuntimeCore.WidgetFactory(
          new DeviceRuntimeCore.HmDomApi(e, t)
        ),
        e.app.__globals__);
try {
  (() => {
    var e = __$$hmAppManager$$__.currentApp,
    t = e.current;
  new DeviceRuntimeCore.WidgetFactory(
    new DeviceRuntimeCore.HmDomApi(e, t),
    "drink"
  );
DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
t.module = DeviceRuntimeCore.Page({
    init_view() {
      
      const isVertical = true
      hmUI.setScrollView(true, 490, 2, isVertical);
      //禁用页面上下滑动
      hmUI.createWidget(hmUI.widget.IMG, {
        x:46,
        y:10,
        src:'icon.png'
      })
      hmUI.createWidget(hmUI.widget.TEXT, {
        
        x: 0,
        y: 160,
        w: 192,
        h: 490,
        color: 0xffffff,
        text_size: 38,
        align_h: hmUI.align.CENTER_H,
        align_v: hmUI.align.TOP,
        text_style: hmUI.text_style.WRAP,
        text: "全新改版"
      })
      hmUI.createWidget(hmUI.widget.TEXT, {
        
        x: 0,
        y: 110,
        w: 192,
        h: 490,
        color: 0x0986d4,
        text_size: 40,
        align_h: hmUI.align.CENTER_H,
        align_v: hmUI.align.TOP,
        text_style: hmUI.text_style.WRAP,
        text: "自习室"
      })
      hmUI.createWidget(hmUI.widget.IMG, {
        x:6,
        y:235,
        src:'start.png'
      }).addEventListener(hmUI.event.CLICK_UP,(function(info){
        hmApp.gotoPage({ url: 'page/192x490_s_l66/index.home', param: '...' })
      }))



  hmUI.createWidget(hmUI.widget.IMG, {
    x:75,
    y:510,
    src:'warning.png'
  })
  hmUI.createWidget(hmUI.widget.TEXT,{
    x:0,
    y:570,
    w:192,
    h:490,
    color: 0xffffff,
    text_size:25,
    align_h: hmUI.align.CENTER_H,
    align_v: hmUI.align.TOP,
    text_style: hmUI.text_style.WRAP,
    text: "警告：长时间使用本小程序可能会有烧屏的风险，为避免烧屏，请不定时用手盖住屏幕以息屏后再打开。"
  })
  hmUI.createWidget(hmUI.widget.BUTTON, {
    x: 35,
    y: 890,
    w: 120,
    h: 70,
    radius: 50,//圆角
    text_size:30,
    normal_color: 0x00fc8c,//一般按钮色
    press_color: 0x094c30,//按压按钮色
    text: '关于',//文字
    click_func: () => {//回调，触发事件
    hmApp.gotoPage({url: "page/192x490_s_l66/index.about",param: "..."})
}})

  
  hmUI.createWidget(hmUI.widget.FILL_RECT,{
    x:25,
    y:560,
    w:146,
    h:3,
    color:0xd81e06,
    radius:2,
  })

    },
    onInit() {
      console.log("index page.js on init invoke"), this.init_view();
    },
    onReady() {
      console.log("index page.js on ready invoke");
    },
    onShow() {
      console.log("index page.js on show invoke");
    },
    onHide() {
      console.log("index page.js on hide invoke");
    },
    onDestory() {
      console.log("index page.js on destory invoke");
    }
  });
})();
} catch (e) {
console.log(e);
}
})();
} catch (e) {
console.log(e);
}