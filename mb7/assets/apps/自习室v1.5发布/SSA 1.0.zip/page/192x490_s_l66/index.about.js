try {
    (() => {
      var e = __$$hmAppManager$$__.currentApp;
      var t = e.current,
        { px: o } =
          (new DeviceRuntimeCore.WidgetFactory(
            new DeviceRuntimeCore.HmDomApi(e, t)
          ),
          e.app.__globals__);
  try {
    (() => {
      var e = __$$hmAppManager$$__.currentApp,
      t = e.current;
    new DeviceRuntimeCore.WidgetFactory(
      new DeviceRuntimeCore.HmDomApi(e, t),
      "drink"
    );
  DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
  t.module = DeviceRuntimeCore.Page({
      init_view() {
        /* 小米手环7并未适配小程序，
        因此所有小程序均以480*480大小渲染，
        而小米手环7分辨率192*490，
        下方10px像素无法利用，
        有超出h480的组件就能上下滑动 */
        const isVertical = true
      hmUI.setScrollView(true, 490, 2, isVertical);
        //禁用页面上下滑动
        
        hmUI.createWidget(hmUI.widget.IMG, {
          x: 45,
          y: 100,
          src: "icon.png"
      })

      hmUI.createWidget(hmUI.widget.TEXT,{
        x:0,
        y:205,
        w:192,
        h:750,
        color: 0xffffff,
        text_size:30,
        align_h: hmUI.align.CENTER_H,
        align_v: hmUI.align.TOP,
        text_style: hmUI.text_style.WRAP,
        text: "自习室"
      })
      hmUI.createWidget(hmUI.widget.TEXT,{
        x:0,
        y:255,
        w:192,
        h:750,
        color: 0xffffff,
        text_size:15,
        align_h: hmUI.align.CENTER_H,
        align_v: hmUI.align.TOP,
        text_style: hmUI.text_style.WRAP,
        text: "Self-Study Assistant"
      })
      hmUI.createWidget(hmUI.widget.TEXT,{
        x:0,
        y:295,
        w:192,
        h:750,
        color: 0xffffff,
        text_size:25,
        align_h: hmUI.align.CENTER_H,
        align_v: hmUI.align.TOP,
        text_style: hmUI.text_style.WRAP,
        text: "Version 1.0"
      })
      hmUI.createWidget(hmUI.widget.TEXT,{
        x:0,
        y:330,
        w:192,
        h:750,
        color: 0xffffff,
        text_size:25,
        align_h: hmUI.align.CENTER_H,
        align_v: hmUI.align.TOP,
        text_style: hmUI.text_style.WRAP,
        text: "作者：Wangyd"
      })
      hmUI.createWidget(hmUI.widget.IMG, {
        x: 0,
        y: 520,
        src: "about.png"
    })
      },
      onInit() {
        console.log("index page.js on init invoke"), this.init_view();
      },
      onReady() {
        console.log("index page.js on ready invoke");
      },
      onShow() {
        console.log("index page.js on show invoke");
      },
      onHide() {
        console.log("index page.js on hide invoke");
      },
      onDestory() {
        console.log("index page.js on destory invoke");
      }
    });
  })();
  } catch (e) {
  console.log(e);
  }
  })();
  } catch (e) {
  console.log(e);
  }